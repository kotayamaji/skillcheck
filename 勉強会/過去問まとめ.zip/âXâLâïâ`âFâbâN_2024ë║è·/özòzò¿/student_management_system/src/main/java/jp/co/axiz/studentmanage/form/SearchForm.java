package jp.co.axiz.studentmanage.form;

/*
 * 検索画面用フォーム
 */
public class SearchForm {

    private String studentName;

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

}
