package jp.co.axiz.productmanage.service;

import java.util.List;

import jp.co.axiz.productmanage.entity.Category;

public interface CategoryService {

	List<Category> findCategories();

}
