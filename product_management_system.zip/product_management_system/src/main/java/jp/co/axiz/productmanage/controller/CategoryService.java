package jp.co.axiz.productmanage.controller;

import java.util.List;

import jp.co.axiz.productmanage.entity.Category;

public interface CategoryService {

	List<Category> findCategories();

}
