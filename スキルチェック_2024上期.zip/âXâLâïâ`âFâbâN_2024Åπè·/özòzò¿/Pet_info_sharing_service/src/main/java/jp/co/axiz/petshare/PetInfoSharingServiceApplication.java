package jp.co.axiz.petshare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetInfoSharingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetInfoSharingServiceApplication.class, args);
	}

}
