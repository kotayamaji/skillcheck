package jp.co.axiz.productmanage.form;

/*
 * 検索画面用フォーム
 */
public class SearchForm {

    private String productName;
    
    private Integer category;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}
    
    

}
