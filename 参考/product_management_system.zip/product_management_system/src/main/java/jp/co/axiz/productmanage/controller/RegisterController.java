package jp.co.axiz.productmanage.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import jakarta.servlet.http.HttpSession;
import jp.co.axiz.productmanage.entity.Categories;
import jp.co.axiz.productmanage.entity.Product;
import jp.co.axiz.productmanage.entity.SessionInfo;
import jp.co.axiz.productmanage.form.LoginForm;
import jp.co.axiz.productmanage.form.RegisterForm;
import jp.co.axiz.productmanage.service.CategoriesService;
import jp.co.axiz.productmanage.service.ProductService;
import jp.co.axiz.productmanage.service.UserService;
import jp.co.axiz.productmanage.util.ParamUtil;

/*
 * 認証処理関連コントローラ
 */
@Controller
public class RegisterController {

    /*
     * セッション情報
     */
    HttpSession session;

    /*
     * ユーザーサービス
     */
    private UserService userInfoService;
    
    private CategoriesService categoriesService;
    
    private ProductService productService;

 
    public RegisterController(HttpSession session, UserService userInfoService, CategoriesService categoriesService,
			ProductService productService) {
		this.session = session;
		this.userInfoService = userInfoService;
		this.categoriesService = categoriesService;
		this.productService = productService;
	}

	//登録画面表示
    @GetMapping("/products/register")
    public String register(@ModelAttribute("register") RegisterForm registerform,@ModelAttribute("loginForm") LoginForm loginForm, Model model ){
    	  // セッション情報を取得
        SessionInfo sessionInfo = ParamUtil.getSessionInfo(session);

        if (sessionInfo.getLoginUser() == null) {
            // ログインしていない場合はトップに戻る
            return "/index";
        }
    	 //カテゴリー一覧取得
        List<Categories> cList = categoriesService.findAll();
        
        session.setAttribute("caList",cList);
    	
    	return "/products/register";
    }
    
    //登録処理
    @GetMapping("/products/regiserResult")
    public String registerResult(@Validated @ModelAttribute("register") RegisterForm registerform, BindingResult bindingResult,@ModelAttribute("loginForm") LoginForm loginForm, Model model) {
    	  // セッション情報を取得
        SessionInfo sessionInfo = ParamUtil.getSessionInfo(session);

        if (sessionInfo.getLoginUser() == null) {
            // ログインしていない場合はトップに戻る
            return "/index";
        }
    	if (bindingResult.hasErrors()) {
          return "/products/register";
      }
    	
    	Product product = new Product();
    	product.setProductName(registerform.getProductName());
    	product.setPrice(registerform.getPrice());
    	product.setCategoryId(registerform.getCategory());
    	product.setRemarks(registerform.getRemarks());
    	
        productService.insert(product);
    	
    	
    	return "/products/menu";
    	
    }
    
    
    
  
}
