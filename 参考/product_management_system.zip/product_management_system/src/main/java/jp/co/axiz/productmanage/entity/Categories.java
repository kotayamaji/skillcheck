package jp.co.axiz.productmanage.entity;

//import jp.co.axiz.productmanage.util.ParamUtil;

/**
 * productsテーブルのEntity
 */
public class Categories {
	private Integer categoryId;
	private String categoryName;
	
	
	public Categories() {
	}


	public Categories(Integer categoryId, String categoryName) {
		this.categoryId = categoryId;
		this.categoryName = categoryName;
	}


	public Integer getCategoryId() {
		return categoryId;
	}


	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}


	public String getCategoryName() {
		return categoryName;
	}


	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
	
   

}