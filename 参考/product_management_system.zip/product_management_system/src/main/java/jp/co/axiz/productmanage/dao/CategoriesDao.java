package jp.co.axiz.productmanage.dao;

import java.util.List;

import jp.co.axiz.productmanage.entity.Categories;

public interface CategoriesDao {
	
	public List<Categories> findAll();
}
