package jp.co.axiz.productmanage.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.axiz.productmanage.dao.CategoriesDao;
import jp.co.axiz.productmanage.entity.Categories;
import jp.co.axiz.productmanage.service.CategoriesService;

/*
 * user_infoテーブル用サービス実装クラス
 */
@Service
@Transactional
public class CategoriesServiceImpl implements CategoriesService {

    private CategoriesDao categoriesDao;

    public CategoriesServiceImpl(CategoriesDao categoriesDao) {
		this.categoriesDao = categoriesDao;
	}


    public List<Categories> findAll(){
    	return categoriesDao.findAll();
    };


}
