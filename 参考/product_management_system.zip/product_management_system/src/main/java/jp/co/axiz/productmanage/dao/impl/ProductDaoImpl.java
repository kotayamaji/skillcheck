package jp.co.axiz.productmanage.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import jakarta.servlet.http.HttpSession;
import jp.co.axiz.productmanage.dao.ProductDao;
import jp.co.axiz.productmanage.entity.Product;
import jp.co.axiz.productmanage.entity.SessionInfo;
import jp.co.axiz.productmanage.entity.User;
import jp.co.axiz.productmanage.util.ParamUtil;

/*
 * user_infoテーブル用DAO
 */
@Repository
public class ProductDaoImpl implements ProductDao {
	
	HttpSession session;

    private NamedParameterJdbcTemplate jdbcTemplate;

//    private static final String SELECT = "SELECT product_id, product_name, price, category_id, " +
//            "remarks, user_id " +
//            "FROM products ";

    private static final String SELECT =  "SELECT  pc.product_id, pc.product_name, pc.price, pc.category_id, pc.remarks, pc.user_id , pc.is_deleted, category_name,u.disp_name FROM (SELECT  p.product_id, p.product_name, p.price, p.category_id, p.remarks, p.user_id , p.is_deleted, category_name From products as p join categories as c on p.category_id = c.category_id) as pc join users as u on pc.user_id = u.user_id "; 
    
    private static final String IS = "Where is_deleted = false ";
    
    private static final String ORDER_BY = " ORDER BY product_id";
    
    private static final String INSERT = "INSERT INTO products (product_name,price,category_id,remarks,user_id, is_deleted) VALUES(:productName,:price,:categoryId,:remarks,:userId,false)";
    
    private static final String DELETE ="UPDATE products SET is_deleted = true Where product_id = :productId ";


    public ProductDaoImpl(HttpSession session, NamedParameterJdbcTemplate jdbcTemplate) {
		super();
		this.session = session;
		this.jdbcTemplate = jdbcTemplate;
	}

	/**
     * 全件取得
     */
    @Override
    public List<Product> findAll() {
        List<Product> resultList = jdbcTemplate.query(SELECT + IS +ORDER_BY,
                new BeanPropertyRowMapper<Product>(Product.class));

        return resultList;
    }

    /**
     * 条件を指定した検索
     */
    @Override
    public List<Product> find(Product product) {

        if (product == null || product.isEmptyCondition()) {
            // 検索条件が無い場合は全検索
            return findAll();
        }

        // 検索条件の有無に応じて、sqlのWHERE句に指定する条件文、
        // Parameterをストックしていく。
        List<String> condition = new ArrayList<String>();
        MapSqlParameterSource param = new MapSqlParameterSource();
        
        Integer productid = product.getProductId();
        Integer categoryId = product.getCategoryId();
        String productName = product.getProductName();

        if (categoryId != null) {
            condition.add("pc.category_id = :categoryId");
            param.addValue("categoryId", categoryId);
        }
        
        if (productid != null) {
            condition.add("pc.product_id = :productId");
            param.addValue("productId", productid);
        }
      

        if (!ParamUtil.isNullOrEmpty(productName)) {
            condition.add("product_name LIKE :productName");
            param.addValue("productName", "%" + productName + "%");
        }

        // WHERE句の文字列生成
        String whereString = String.join(" AND ", condition.toArray(new String[] {}));

        // SQL文生成
        String sql = SELECT + "WHERE is_deleted = false AND " + whereString + ORDER_BY ;

        // SQL文実行
        List<Product> resultList = jdbcTemplate.query(sql, param, new BeanPropertyRowMapper<Product>(Product.class));

        return resultList;
    }
    
    public void register(Product product) {
    	 MapSqlParameterSource param = new MapSqlParameterSource();
    	   // セッション情報を取得
         SessionInfo sessionInfo = ParamUtil.getSessionInfo(session);
         User user =sessionInfo.getLoginUser();
         Integer userId =user.getUserId();
    	 
    	 param.addValue("productName",product.getProductName() );
    	 param.addValue("price",product.getPrice() );
    	 param.addValue("categoryId",product.getCategoryId() );
    	 param.addValue("remarks",product.getRemarks() );
    	 param.addValue("userId", userId);
    	 
    	 
    	// SQL実行
         jdbcTemplate.update(INSERT, param);
    	 
    }
    
    public void delete(Integer productId) {
    	MapSqlParameterSource param = new MapSqlParameterSource();
    	param.addValue("productId", productId);
    	 jdbcTemplate.update(DELETE, param);
    	
    }

}
