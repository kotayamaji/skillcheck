package jp.co.axiz.productmanage.dao.impl;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import jp.co.axiz.productmanage.dao.CategoriesDao;
import jp.co.axiz.productmanage.entity.Categories;

@Repository
public class CategoriesDaoImple implements CategoriesDao{
    private NamedParameterJdbcTemplate jdbcTemplate;

	public CategoriesDaoImple(NamedParameterJdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	  
    private String SELECT_ALL = "SELECT * FROM categories ORDER BY category_id";
    
    public List<Categories> findAll(){
    	
    	List<Categories> resultList = jdbcTemplate.query(SELECT_ALL,
                new BeanPropertyRowMapper<Categories>(Categories.class));
    	return resultList;
    }
	 
	
}
