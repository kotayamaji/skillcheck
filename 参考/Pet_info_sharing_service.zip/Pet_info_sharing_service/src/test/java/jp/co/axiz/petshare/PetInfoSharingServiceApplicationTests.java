package jp.co.axiz.petshare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetInfoSharingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
