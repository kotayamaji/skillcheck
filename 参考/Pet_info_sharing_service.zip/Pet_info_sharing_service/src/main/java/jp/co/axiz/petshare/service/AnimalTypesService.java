package jp.co.axiz.petshare.service;

import java.util.List;

import jp.co.axiz.petshare.entity.AnimalType;

public interface AnimalTypesService {
	public List<AnimalType> findAll();
}
