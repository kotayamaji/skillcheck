package jp.co.axiz.petshare.form;

/*
 * 検索画面用フォーム
 */
public class SearchForm {

	private String name;
	private Integer animalTypeId;

	public Integer getAnimalTypeId() {
		return animalTypeId;
	}

	public void setAnimalTypeId(Integer animalTypeId) {
		this.animalTypeId = animalTypeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
